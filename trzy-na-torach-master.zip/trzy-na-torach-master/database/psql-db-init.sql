----------------------------------------------------------------------------------------------------
--
-- Database Init
--
----------------------------------------------------------------------------------------------------

BEGIN TRANSACTION;

--------------------------------------------------
-- Purge previous database
--------------------------------------------------
DROP TABLE IF EXISTS zespoly CASCADE;
DROP TABLE IF EXISTS sponsorzy CASCADE;
DROP TABLE IF EXISTS sponsor_zespol;
DROP TABLE IF EXISTS model CASCADE;
DROP TABLE IF EXISTS samochody CASCADE;
DROP TABLE IF EXISTS pracownicy CASCADE;
DROP TABLE IF EXISTS kierowcy CASCADE;
DROP TABLE IF EXISTS inzynier;
DROP TABLE IF EXISTS trener;
DROP TABLE IF EXISTS mechanik CASCADE;
DROP TABLE IF EXISTS serwis CASCADE;
DROP TABLE IF EXISTS mechanik_serwis;
DROP TABLE IF EXISTS tory CASCADE;
DROP TABLE IF EXISTS wyscigi CASCADE;
DROP TABLE IF EXISTS wyniki;
DROP TABLE IF EXISTS rekordy;
DROP SEQUENCE IF EXISTS seq_model_id;
DROP PROCEDURE IF EXISTS sp_wstaw_kierowce;
DROP PROCEDURE IF EXISTS sp_wstaw_inzyniera;
DROP PROCEDURE IF EXISTS sp_wstaw_trenera;
DROP PROCEDURE IF EXISTS sp_wstaw_mechanika;
DROP PROCEDURE IF EXISTS sp_wstaw_samochod;
DROP PROCEDURE IF EXISTS sp_wstaw_serwis;
DROP PROCEDURE IF EXISTS sp_wstaw_sponsora;
DROP PROCEDURE IF EXISTS sp_wstaw_rekord;
DROP PROCEDURE IF EXISTS sp_wstaw_wynik;
DROP FUNCTION IF EXISTS sf_oblicz_punkty;

--------------------------------------------------
-- Deploy tables
--------------------------------------------------
CREATE TABLE zespoly (
    nazwa_zesp         VARCHAR(64) NOT NULL,
    kraj_zesp          VARCHAR(64) NOT NULL,
    repr_marka         VARCHAR(64) NOT NULL
);

CREATE TABLE sponsorzy (
    lei                VARCHAR(20) NOT NULL,
    nazwa_spon         VARCHAR(32) NOT NULL,
    kraj_spon          VARCHAR(32) NOT NULL,
    kapital            NUMERIC NOT NULL CHECK (kapital > 0)
);

CREATE TABLE sponsor_zespol (
    sponsorzy_lei      VARCHAR(20) NOT NULL,
    zespoly_nazwa_zesp VARCHAR(64) NOT NULL
);

CREATE TABLE model (
    model_id           INT NOT NULL,
    nazwa_mod          VARCHAR(64) NOT NULL,
    nazwa_mar          VARCHAR(64) NOT NULL
);

CREATE TABLE samochody (
    vin                VARCHAR(17) NOT NULL,
    nazwa_zesp         VARCHAR(64) NOT NULL,
    moc                NUMERIC NOT NULL CHECK (moc > 0),
    masa               NUMERIC NOT NULL CHECK (masa > 0),
    rok_prod           DATE,
    model_id           INT NOT NULL
);

CREATE TABLE pracownicy (
    pesel              VARCHAR(11),
    stanowisko         VARCHAR(64) NOT NULL,
    nazwisko           VARCHAR(64) NOT NULL,
    placa              NUMERIC CHECK (placa > 0),
    nazwa_zesp         VARCHAR(64) NOT NULL
);

CREATE TABLE kierowcy (
    pesel              VARCHAR(11) NOT NULL,
    data_ur            DATE NOT NULL,
    kraj_ur            VARCHAR(64) NOT NULL,
    numer_start        INT,
    model_id           INT NOT NULL
);

CREATE TABLE inzynier (
    pesel              VARCHAR(11) NOT NULL,
    nazwa_uczel        VARCHAR(64) NOT NULL,
    spec               VARCHAR(64) NOT NULL
);

CREATE TABLE trener (
    pesel              VARCHAR(11) NOT NULL,
    dosw_od            DATE NOT NULL
);

CREATE TABLE mechanik (
    pesel              VARCHAR(11) NOT NULL,
    rola               VARCHAR(64) NOT NULL
);

CREATE TABLE serwis (
    vin                VARCHAR(17) NOT NULL,
    data_rozp          TIMESTAMP NOT NULL,
    data_zak           TIMESTAMP NOT NULL CHECK (data_zak > data_rozp),
    nazwa_zmian        VARCHAR(64) NOT NULL,
    koszt              NUMERIC CHECK (koszt >= 0),
    opis               VARCHAR(255)
);

CREATE TABLE mechanik_serwis (
    mechanik_pesel     VARCHAR(11) NOT NULL,
    serwis_vin         VARCHAR(17) NOT NULL,
    serwis_data_rozp   TIMESTAMP NOT NULL
);

CREATE TABLE tory (
    nazwa_tor          VARCHAR(64) NOT NULL,
    dlugosc            NUMERIC NOT NULL CHECK (dlugosc > 0),
    kraj_tor           VARCHAR(64) NOT NULL,
    adres              VARCHAR(255),
    data_otw           DATE,
    pojemnosc          INT
);

CREATE TABLE wyscigi (
    nazwa_wys          VARCHAR(64) NOT NULL,
    nazwa_tor          VARCHAR(64) NOT NULL,
    ilosc_okr          INT NOT NULL,
    data_wys           DATE NOT NULL
);

CREATE TABLE wyniki (
    nazwa_wys          VARCHAR(64) NOT NULL,
    pozycja            INT NOT NULL,
    pesel              VARCHAR(11) NOT NULL
);

CREATE TABLE rekordy (
    pesel              VARCHAR(11) NOT NULL,
    czas               INTERVAL NOT NULL CHECK (czas > '00:00:00.000'),
    nazwa_wys          VARCHAR(64) NOT NULL,
    numer_okr          INT
);


--------------------------------------------------
-- Alter tables - primary/foreign keys
--------------------------------------------------
ALTER TABLE zespoly ADD CONSTRAINT pk_zespoly PRIMARY KEY (nazwa_zesp);

ALTER TABLE sponsorzy ADD CONSTRAINT pk_sponsorzy PRIMARY KEY (lei);

ALTER TABLE sponsor_zespol ADD CONSTRAINT pk_sponsor_zespol PRIMARY KEY (sponsorzy_lei, zespoly_nazwa_zesp);
ALTER TABLE sponsor_zespol ADD CONSTRAINT fk_sponsor_zespol_sponsorzy FOREIGN KEY (sponsorzy_lei) REFERENCES sponsorzy (lei);
ALTER TABLE sponsor_zespol ADD CONSTRAINT fk_sponsor_zespol_zespoly FOREIGN KEY (zespoly_nazwa_zesp) REFERENCES zespoly (nazwa_zesp);

ALTER TABLE model ADD CONSTRAINT pk_model PRIMARY KEY (model_id);
ALTER TABLE model ADD UNIQUE (nazwa_mod, nazwa_mar);

ALTER TABLE samochody ADD CONSTRAINT pk_samochody PRIMARY KEY (vin);
ALTER TABLE samochody ADD CONSTRAINT fk_samochody_zespoly FOREIGN KEY (nazwa_zesp) REFERENCES zespoly (nazwa_zesp);
ALTER TABLE samochody ADD CONSTRAINT fk_samochody_model FOREIGN KEY (model_id) REFERENCES model (model_id);

ALTER TABLE pracownicy ADD CONSTRAINT pk_pracownicy PRIMARY KEY (pesel);
ALTER TABLE pracownicy ADD CONSTRAINT fk_pracownicy_zespoly FOREIGN KEY (nazwa_zesp) REFERENCES zespoly (nazwa_zesp);

ALTER TABLE kierowcy ADD CONSTRAINT pk_kierowcy PRIMARY KEY (pesel);
ALTER TABLE kierowcy ADD CONSTRAINT fk_kierowcy_pracownicy FOREIGN KEY (pesel) REFERENCES pracownicy (pesel);
ALTER TABLE kierowcy ADD CONSTRAINT fk_kierowcy_model FOREIGN KEY (model_id) REFERENCES model (model_id) ;

ALTER TABLE inzynier ADD CONSTRAINT pk_inzynier PRIMARY KEY (pesel);
ALTER TABLE inzynier ADD CONSTRAINT fk_inzynier_pracownicy FOREIGN KEY (pesel) REFERENCES pracownicy (pesel);

ALTER TABLE trener ADD CONSTRAINT pk_trener PRIMARY KEY (pesel);
ALTER TABLE trener ADD CONSTRAINT fk_trener_pracownicy FOREIGN KEY (pesel) REFERENCES pracownicy (pesel);

ALTER TABLE mechanik ADD CONSTRAINT pk_mechanik PRIMARY KEY (pesel);
ALTER TABLE mechanik ADD CONSTRAINT fk_mechanik_pracownicy FOREIGN KEY (pesel) REFERENCES pracownicy (pesel);

ALTER TABLE serwis ADD CONSTRAINT pk_serwis PRIMARY KEY (vin, data_rozp);
ALTER TABLE serwis ADD CONSTRAINT fk_serwis_samochody FOREIGN KEY (vin) REFERENCES samochody (vin);

ALTER TABLE mechanik_serwis ADD CONSTRAINT pk_mechanik_serwis PRIMARY KEY (mechanik_pesel, serwis_vin, serwis_data_rozp);
ALTER TABLE mechanik_serwis ADD CONSTRAINT fk_mechanik_serwis_mechanik FOREIGN KEY (mechanik_pesel) REFERENCES mechanik (pesel);
ALTER TABLE mechanik_serwis ADD CONSTRAINT fk_mechanik_serwis_serwis FOREIGN KEY (serwis_vin, serwis_data_rozp) REFERENCES serwis (vin, data_rozp);

ALTER TABLE tory ADD CONSTRAINT pk_tory PRIMARY KEY (nazwa_tor);

ALTER TABLE wyscigi ADD CONSTRAINT pk_wyscigi PRIMARY KEY (nazwa_wys);
ALTER TABLE wyscigi ADD CONSTRAINT fk_wyscigi_tory FOREIGN KEY (nazwa_tor) REFERENCES tory (nazwa_tor);

ALTER TABLE wyniki ADD CONSTRAINT pk_wyniki PRIMARY KEY (nazwa_wys, pesel);
ALTER TABLE wyniki ADD CONSTRAINT fk_wyniki_wyscigi FOREIGN KEY (nazwa_wys) REFERENCES wyscigi (nazwa_wys);
ALTER TABLE wyniki ADD CONSTRAINT fk_wyniki_kierowcy FOREIGN KEY (pesel) REFERENCES kierowcy (pesel);

ALTER TABLE rekordy ADD CONSTRAINT pk_rekordy PRIMARY KEY (pesel, nazwa_wys);
ALTER TABLE rekordy ADD CONSTRAINT un_rekordy UNIQUE (nazwa_wys);
ALTER TABLE rekordy ADD CONSTRAINT fk_rekordy_kierowcy FOREIGN KEY (pesel) REFERENCES kierowcy (pesel);
ALTER TABLE rekordy ADD CONSTRAINT fk_rekordy_wyscigi FOREIGN KEY (nazwa_wys) REFERENCES wyscigi (nazwa_wys);


--------------------------------------------------
-- Create indexes
--------------------------------------------------
CREATE UNIQUE INDEX idx_model ON model (model_id ASC);
CREATE UNIQUE INDEX idx_samochody ON samochody (vin ASC);
CREATE UNIQUE INDEX idx_pracownicy ON pracownicy (pesel ASC);
CREATE UNIQUE INDEX idx_rekordy ON rekordy (nazwa_wys ASC);


--------------------------------------------------
-- Deploy sequences
--------------------------------------------------
CREATE SEQUENCE seq_model_id START 100000000;


--------------------------------------------------
-- Deploy stored procedures
--------------------------------------------------
CREATE OR REPLACE PROCEDURE sp_wstaw_kierowce (
    p_pesel       pracownicy.pesel%TYPE,
    p_nazwisko    pracownicy.nazwisko%TYPE,
    p_placa       pracownicy.placa%TYPE,
    p_nazwa_zesp  pracownicy.nazwa_zesp%TYPE,
    p_data_ur     kierowcy.data_ur%TYPE,
    p_kraj_ur     kierowcy.kraj_ur%TYPE,
    p_numer_start kierowcy.numer_start%TYPE,
    p_model_id    kierowcy.model_id%TYPE
) AS $$
BEGIN
    PERFORM * FROM zespoly WHERE zespoly.nazwa_zesp = p_nazwa_zesp;
    IF NOT FOUND THEN RAISE EXCEPTION 'Zespół "%" nie istnieje', $4; END IF;
    PERFORM * FROM model WHERE model.model_id = p_model_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'Nie istnieje model o podanym identyfikatorze'; END IF;

    INSERT INTO pracownicy VALUES (p_pesel, 'kierowca', p_nazwisko, p_placa, p_nazwa_zesp);
    INSERT INTO kierowcy VALUES (p_pesel, p_data_ur, p_kraj_ur, p_numer_start, p_model_id);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_inzyniera (
    p_pesel       pracownicy.pesel%TYPE,
    p_nazwisko    pracownicy.nazwisko%TYPE,
    p_placa       pracownicy.placa%TYPE,
    p_nazwa_zesp  pracownicy.nazwa_zesp%TYPE,
    p_nazwa_uczel inzynier.nazwa_uczel%TYPE,
    p_spec        inzynier.spec%TYPE
) AS $$
BEGIN
    PERFORM * FROM zespoly WHERE zespoly.nazwa_zesp = p_nazwa_zesp;
    IF NOT FOUND THEN RAISE EXCEPTION 'Zespół "%" nie istnieje', $4; END IF;

    INSERT INTO pracownicy VALUES (p_pesel, 'inzynier', p_nazwisko, p_placa, p_nazwa_zesp);
    INSERT INTO inzynier VALUES (p_pesel, p_nazwa_uczel, p_spec);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_trenera (
    p_pesel       pracownicy.pesel%TYPE,
    p_nazwisko    pracownicy.nazwisko%TYPE,
    p_placa       pracownicy.placa%TYPE,
    p_nazwa_zesp  pracownicy.nazwa_zesp%TYPE,
    p_dosw_od     trener.dosw_od%TYPE
) AS $$
BEGIN
    PERFORM * FROM zespoly WHERE zespoly.nazwa_zesp = p_nazwa_zesp;
    IF NOT FOUND THEN RAISE EXCEPTION 'Zespół "%" nie istnieje', $4; END IF;

    INSERT INTO pracownicy VALUES (p_pesel, 'trener', p_nazwisko, p_placa, p_nazwa_zesp);
    INSERT INTO trener VALUES (p_pesel, p_dosw_od);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_mechanika (
    p_pesel       pracownicy.pesel%TYPE,
    p_nazwisko    pracownicy.nazwisko%TYPE,
    p_placa       pracownicy.placa%TYPE,
    p_nazwa_zesp  pracownicy.nazwa_zesp%TYPE,
    p_rola        mechanik.rola%TYPE
) AS $$
BEGIN
    PERFORM * FROM zespoly WHERE zespoly.nazwa_zesp = p_nazwa_zesp;
    IF NOT FOUND THEN RAISE EXCEPTION 'Zespół "%" nie istnieje', $4; END IF;

    INSERT INTO pracownicy VALUES (p_pesel, 'mechanik', p_nazwisko, p_placa, p_nazwa_zesp);
    INSERT INTO mechanik VALUES (p_pesel, p_rola);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_samochod (
    p_vin         samochody.vin%TYPE,
    p_model       model.nazwa_mod%TYPE,
    p_marka       model.nazwa_mar%TYPE,
    p_nazwa_zesp  samochody.nazwa_zesp%TYPE,
    p_moc         samochody.moc%TYPE,
    p_masa        samochody.masa%TYPE,
    p_rok_prod    samochody.rok_prod%TYPE
) AS $$
DECLARE
    v_model_id    INT;
    c_model CURSOR (
        p_model   VARCHAR,
        p_marka   VARCHAR
    ) FOR SELECT model_id FROM model WHERE model.nazwa_mod = p_model AND model.nazwa_mar = p_marka;
BEGIN
    PERFORM * FROM zespoly WHERE zespoly.nazwa_zesp = p_nazwa_zesp;
    IF NOT FOUND THEN RAISE EXCEPTION 'Zespół "%" nie istnieje', $4; END IF;

    OPEN c_model(p_model, p_marka);
    FETCH c_model INTO v_model_id;
    IF NOT FOUND THEN
        RAISE NOTICE 'INFO: Nie znaleziono "% %" w bazie - rekord zostanie dodany automatycznie', $3, $2;
        v_model_id = nextval('seq_model_id');
        INSERT INTO model VALUES (v_model_id, p_model, p_marka);
    END IF;
    CLOSE c_model;
    INSERT INTO samochody VALUES (p_vin, p_nazwa_zesp, p_moc, p_masa, p_rok_prod, v_model_id);

END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_serwis (
    p_vin         serwis.vin%TYPE,
    p_pesel_mech  mechanik_serwis.mechanik_pesel%TYPE,
    p_nazwa_zmian serwis.nazwa_zmian%TYPE,
    p_data_rozp   serwis.data_rozp%TYPE,
    p_data_zak    serwis.data_zak%TYPE DEFAULT '9999-12-31',
    p_koszt       serwis.koszt%TYPE DEFAULT 0,
    p_opis        serwis.opis%TYPE DEFAULT ''
) AS $$
BEGIN
    PERFORM * FROM samochody WHERE samochody.vin = p_vin;
    IF NOT FOUND THEN RAISE EXCEPTION 'Nie istnieje samochód o numerze VIN "%"', $1; END IF;
    PERFORM * FROM mechanik WHERE mechanik.pesel = p_pesel_mech;
    IF NOT FOUND THEN RAISE EXCEPTION 'Nie istnieje mechanik o peselu "%"', $2; END IF;

    INSERT INTO serwis VALUES (p_vin, p_data_rozp, p_data_zak, p_nazwa_zmian, p_koszt, p_opis);
    INSERT INTO mechanik_serwis VALUES (p_pesel_mech, p_vin, p_data_rozp);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_sponsora (
    p_lei         sponsorzy.lei%TYPE,
    p_nazwa_spon  sponsorzy.nazwa_spon%TYPE,
    p_nazwa_zesp  zespoly.nazwa_zesp%TYPE,
    p_kraj_spon   sponsorzy.kraj_spon%TYPE,
    p_kapital     sponsorzy.kapital%TYPE
) AS $$
BEGIN
    PERFORM * FROM zespoly WHERE zespoly.nazwa_zesp = p_nazwa_zesp;
    IF NOT FOUND THEN RAISE EXCEPTION 'Zespół "%" nie istnieje', $4; END IF;

    INSERT INTO sponsorzy VALUES (p_lei, p_nazwa_spon, p_kraj_spon, p_kapital);
    INSERT INTO sponsor_zespol VALUES(p_lei, p_nazwa_zesp);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_rekord (
    p_pesel       kierowcy.pesel%TYPE,
    p_nazwa_wys   rekordy.nazwa_wys%TYPE,
    p_czas        rekordy.czas%TYPE,
    p_numer_okr   rekordy.numer_okr%TYPE DEFAULT NULL
) AS $$
DECLARE
    v_czas INTERVAL;
    v_flag INT := 1;
    c_czas CURSOR (
        p_nazwa_wys VARCHAR
    ) FOR SELECT czas FROM rekordy WHERE rekordy.nazwa_wys = p_nazwa_wys;
BEGIN
    PERFORM * FROM kierowcy WHERE kierowcy.pesel = p_pesel;
    IF NOT FOUND THEN RAISE EXCEPTION 'Nie istnieje kierowca o peselu "%"', $1; END IF;
    PERFORM * FROM wyscigi WHERE wyscigi.nazwa_wys = p_nazwa_wys;
    IF NOT FOUND THEN RAISE EXCEPTION 'Wyścig "%" nie istnieje', $2; END IF;

    PERFORM rekordy.nazwa_wys FROM rekordy WHERE rekordy.nazwa_wys = p_nazwa_wys;
    IF FOUND THEN
        RAISE NOTICE 'INFO: Rekord wyścigu "%" istnieje w bazie', $2;
        OPEN c_czas(p_nazwa_wys);
        FETCH c_czas INTO v_czas;
        IF p_czas < v_czas THEN
            DELETE FROM rekordy WHERE rekordy.nazwa_wys = p_nazwa_wys;
            v_flag := 1;
        ELSE
            v_flag := 0;
        END IF;
        CLOSE c_czas;
    END IF;

    IF v_flag = 1 THEN
        INSERT INTO rekordy VALUES (p_pesel, p_czas, p_nazwa_wys, p_numer_okr);
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE PROCEDURE sp_wstaw_wynik (
    p_nazwa_wys   wyniki.nazwa_wys%TYPE,
    p_pesel       wyniki.pesel%TYPE,
    p_pozycja     wyniki.pozycja%TYPE
) AS $$
BEGIN
    PERFORM * FROM kierowcy WHERE kierowcy.pesel = p_pesel;
    IF NOT FOUND THEN RAISE EXCEPTION 'Nie istnieje kierowca o peselu "%"', $2; END IF;
    PERFORM * FROM wyscigi WHERE wyscigi.nazwa_wys = p_nazwa_wys;
    IF NOT FOUND THEN RAISE EXCEPTION 'Wyścig "%" nie istnieje', $1; END IF;

    INSERT INTO wyniki VALUES (p_nazwa_wys, p_pozycja, p_pesel);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION sf_oblicz_punkty (
    p_pesel       wyniki.pesel%TYPE,
    p_nazwa_wys   wyniki.nazwa_wys%TYPE
)
RETURNS INT
AS $$
DECLARE
    v_pozycja       INT;
    v_data_wys      INT;
    c_pozycja CURSOR (
        p_pesel     VARCHAR,
        p_nazwa_wys VARCHAR
    ) FOR SELECT pozycja FROM wyniki WHERE wyniki.pesel = p_pesel AND wyniki.nazwa_wys = p_nazwa_wys;
    c_data_wys CURSOR (
        p_nazwa_wys VARCHAR
    ) FOR SELECT EXTRACT(YEAR FROM data_wys) FROM wyscigi WHERE wyscigi.nazwa_wys = p_nazwa_wys;
BEGIN
    PERFORM * FROM kierowcy WHERE kierowcy.pesel = p_pesel;
    IF NOT FOUND THEN RAISE EXCEPTION 'Nie istnieje kierowca o peselu "%"', $1; END IF;

    OPEN c_pozycja(p_pesel, p_nazwa_wys);
    FETCH c_pozycja INTO v_pozycja;

    OPEN c_data_wys(p_nazwa_wys);
    FETCH c_data_wys INTO v_data_wys;

    IF v_data_wys > 2010 THEN
        CASE
            WHEN v_pozycja=1 THEN RETURN 25;
            WHEN v_pozycja=2 THEN RETURN 18;
            WHEN v_pozycja=3 THEN RETURN 15;
            WHEN v_pozycja=4 THEN RETURN 12;
            WHEN v_pozycja=5 THEN RETURN 10;
            WHEN v_pozycja=6 THEN RETURN 8;
            WHEN v_pozycja=7 THEN RETURN 6;
            WHEN v_pozycja=8 THEN RETURN 4;
            WHEN v_pozycja=9 THEN RETURN 2;
            WHEN v_pozycja=10 THEN RETURN 1;
            ELSE RETURN 0;
        END CASE;
    ELSIF v_data_wys > 2005 THEN
        CASE
            WHEN v_pozycja=1 THEN RETURN 10;
            WHEN v_pozycja=2 THEN RETURN 8;
            WHEN v_pozycja=3 THEN RETURN 6;
            WHEN v_pozycja=4 THEN RETURN 5;
            WHEN v_pozycja=5 THEN RETURN 4;
            WHEN v_pozycja=6 THEN RETURN 3;
            WHEN v_pozycja=7 THEN RETURN 2;
            WHEN v_pozycja=8 THEN RETURN 1;
        ELSE RETURN 0;
        END CASE;

    ELSE
        RAISE NOTICE 'INFO: Data wykracza poza zakres systemów obliczania punktów, przyjmuję system z roku 1987';
        CASE
            WHEN v_pozycja=1 THEN RETURN 20;
            WHEN v_pozycja=2 THEN RETURN 15;
            WHEN v_pozycja=3 THEN RETURN 12;
            WHEN v_pozycja=4 THEN RETURN 10;
            WHEN v_pozycja=5 THEN RETURN 8;
            WHEN v_pozycja=6 THEN RETURN 6;
            WHEN v_pozycja=7 THEN RETURN 4;
            WHEN v_pozycja=8 THEN RETURN 3;
            WHEN v_pozycja=9 THEN RETURN 2;
            WHEN v_pozycja=10 THEN RETURN 1;
            ELSE RETURN 0;
        END CASE;
    END IF;

    CLOSE c_pozycja;
    CLOSE c_data_wys;

END;
$$ LANGUAGE plpgsql;


--------------------------------------------------
-- Grant permissions for django_user
--------------------------------------------------
GRANT ALL ON ALL TABLES IN SCHEMA public TO django_user;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO django_user;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO django_user;

COMMIT;
END TRANSACTION;