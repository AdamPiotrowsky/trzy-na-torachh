# Założenia

Proponowany przez nas program bazodanowy służyłby do kolekcjonowania informacji na temat mistrzostw samochodów turystycznych (WTCC, *ang. World Touring Car Championship*), wyścigów oraz uczestników tych mistrzostw. 

# Funkcjonalność

Program pozwalałby na dodawanie danych poprzez dedykowane formularze (np. formularz dla zespołów wyścigowych, formularz dla sponsorów mistrzostw, formularz dla administratorów mistrzostw), oferowałby panel administracyjny (np. zmodyfikowany i rozbudowany domyślny panel administracyjny frameworka *Django/PHP Laravel*, bądź dedykowany widok panelu administracyjnego) oraz widoki pozwalające na wyciąganie statystyk odnośnie wyścigów/rekordów itp.

# Przykładowe encje

1. Encja ‘Samochody’
2. Encja ‘Tory wyścigowe’
3. Encja ‘Pracownicy’
4. Encja ‘Kierowcy’
5. Encja ‘Zespoły’
6. Encja ‘Wyścigi’
7. Encja ‘Mistrzostwa’
8. Encja ‘Sponsorzy’
9. Encja ‘Naprawy’
10. Encja ‘Rekordy’
11. Encja systemowa ‘Użytkownicy’

# Diagram encji

![diagram przedstawiający związki pomiędzy encjami](./diagram-erd.png)

# Diagram relacji

![diagram przedstawiający związki pomiędzy encjami](./diagram-rel.png)

# Stack technologiczny

W skład rozpatrywanych technologii wchodzą: 

- technologia bazodanowa działająca natywnie pod systemem Linux oraz MS Windows (np. MariaDB, PostgreSQL),
- framework MVC (ang. Model-View-controller) służący do implementacji aplikacji webowej oraz obsługi bazy danych (np. Python Django, PHP Laravel),
- framework front-endowy pozwalający na wygenerowanie warstwy graficznej aplikacji (np. Bootstrap)
