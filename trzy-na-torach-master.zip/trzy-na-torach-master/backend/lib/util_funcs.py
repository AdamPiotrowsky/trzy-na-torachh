from django.db import connection


def dictfetchall(cursor):
    """
    Return all rows from a SQL cursor as a dict
    """
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]


def delete_employee_data(profession, employee_id):
    """
    Function used to delete specific employee from the database
    """
    with connection.cursor() as cursor:
        if profession == "kierowca":  # delete driver data from the table
            cursor.execute("DELETE FROM rekordy r WHERE r.pesel=%s", (employee_id,))
            cursor.execute("DELETE FROM wyniki w WHERE w.pesel=%s", (employee_id,))
            cursor.execute("DELETE FROM kierowcy k WHERE k.pesel=%s", (employee_id,))
        if profession == "inzynier":  # delete engineer data from the table
            cursor.execute("DELETE FROM inzynier i WHERE i.pesel=%s", (employee_id,))
        if profession == "trener":  # delete coach data from the table
            cursor.execute("DELETE FROM trener t WHERE t.pesel=%s", (employee_id,))
        if profession == "mechanik":  # delete mechanic data from the table
            with connection.cursor() as cursor1:
                cursor1.execute("SELECT serwis_data_rozp FROM mechanik_serwis WHERE mechanik_pesel=%s", (employee_id,))
                data_rozp = cursor1.fetchone()
            cursor.execute("DELETE FROM mechanik_serwis ms WHERE ms.mechanik_pesel=%s", (employee_id,))
            # TODO [refactor]: should data from 'serwis' be deleted, when the mechanic record is deleted?
            cursor.execute("DELETE FROM serwis s WHERE s.data_rozp=%s", (data_rozp, ))
            cursor.execute("DELETE FROM mechanik m WHERE m.pesel=%s", (employee_id,))
        cursor.execute("DELETE FROM pracownicy p WHERE p.pesel=%s", (employee_id,))


def delete_car_data(car_id):
    """
    Function used to delete car from the database
    """
    with connection.cursor() as cursor:
        cursor.execute("DELETE FROM mechanik_serwis ms WHERE ms.serwis_vin=%s", (car_id,))
        cursor.execute("DELETE FROM serwis s WHERE s.vin=%s", (car_id,))
        cursor.execute("DELETE FROM samochody s WHERE s.vin=%s", (car_id,))


def delete_team_foreign_records(team_id):
    """
    View used to delete team data from the database
    """
    with connection.cursor() as cursor:  # delete employees data from the table
        cursor.execute("SELECT pesel, stanowisko FROM pracownicy WHERE nazwa_zesp=%s", (team_id,))
        employees = dictfetchall(cursor)
        for employee in employees:
            delete_employee_data(employee["stanowisko"], employee["pesel"])
    with connection.cursor() as cursor:  # delete cars data from the table
        cursor.execute("SELECT vin FROM samochody WHERE nazwa_zesp=%s", (team_id,))
        cars = dictfetchall(cursor)
        for car in cars:
            delete_car_data(car["vin"])
    with connection.cursor() as cursor:  # delete sponsors data from the table
        cursor.execute("DELETE FROM sponsor_zespol WHERE zespoly_nazwa_zesp=%s", (team_id,))


def delete_model_foreign_records(model_id):
    """
    Function used to delete cars from the database
    """
    with connection.cursor() as cursor:  # delete cars data from the table
        cursor.execute("SELECT vin FROM samochody WHERE model_id=%s", (model_id,))
        cars = dictfetchall(cursor)
        for car in cars:
            delete_car_data(car["vin"])
    with connection.cursor() as cursor:  # delete drivers data from the table
        cursor.execute("SELECT pesel FROM kierowcy WHERE model_id=%s", (model_id,))
        drivers = dictfetchall(cursor)
        for driver in drivers:
            delete_employee_data("kierowca", driver["pesel"])


def delete_race_data(race_id):
    """
    Function used to delete race from the database
    """
    with connection.cursor() as cursor:
        cursor.execute("DELETE FROM wyniki w WHERE w.nazwa_wys = %s", (race_id, ))
        cursor.execute("DELETE FROM rekordy r WHERE r.nazwa_wys = %s", (race_id,))
        cursor.execute("DELETE FROM wyscigi w WHERE w.nazwa_wys = %s", (race_id, ))


def delete_track_foreign_records(track_id):
    """
    Function used to delete race from the database
    """
    with connection.cursor() as cursor:  # delete races data from the table
        cursor.execute("SELECT nazwa_wys FROM wyscigi WHERE nazwa_tor=%s", (track_id,))
        races = dictfetchall(cursor)
        for race in races:
            delete_race_data(race["nazwa_wys"])