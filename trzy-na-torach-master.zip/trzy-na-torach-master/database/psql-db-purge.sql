----------------------------------------------------------------------------------------------------
--
-- Purge Database
--
----------------------------------------------------------------------------------------------------

BEGIN TRANSACTION;

DROP TABLE IF EXISTS zespoly CASCADE;
DROP TABLE IF EXISTS sponsorzy CASCADE;
DROP TABLE IF EXISTS sponsor_zespol;
DROP TABLE IF EXISTS model CASCADE;
DROP TABLE IF EXISTS samochody CASCADE;
DROP TABLE IF EXISTS pracownicy CASCADE;
DROP TABLE IF EXISTS kierowcy CASCADE;
DROP TABLE IF EXISTS inzynier;
DROP TABLE IF EXISTS trener;
DROP TABLE IF EXISTS mechanik CASCADE;
DROP TABLE IF EXISTS serwis CASCADE;
DROP TABLE IF EXISTS mechanik_serwis;
DROP TABLE IF EXISTS tory CASCADE;
DROP TABLE IF EXISTS wyscigi CASCADE;
DROP TABLE IF EXISTS wyniki;
DROP TABLE IF EXISTS rekordy;
DROP SEQUENCE IF EXISTS seq_model_id;
DROP PROCEDURE IF EXISTS sp_wstaw_kierowce;
DROP PROCEDURE IF EXISTS sp_wstaw_inzyniera;
DROP PROCEDURE IF EXISTS sp_wstaw_trenera;
DROP PROCEDURE IF EXISTS sp_wstaw_mechanika;
DROP PROCEDURE IF EXISTS sp_wstaw_samochod;
DROP PROCEDURE IF EXISTS sp_wstaw_serwis;
DROP PROCEDURE IF EXISTS sp_wstaw_sponsora;
DROP PROCEDURE IF EXISTS sp_wstaw_rekord;
DROP PROCEDURE IF EXISTS sp_wstaw_wynik;
DROP FUNCTION IF EXISTS sf_oblicz_punkty;

COMMIT;
END TRANSACTION;