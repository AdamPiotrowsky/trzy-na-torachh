from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.db import connection, transaction
from django.db.utils import DataError, Error, InternalError, IntegrityError
from lib.util_funcs import dictfetchall, delete_employee_data, delete_team_foreign_records, delete_car_data, delete_model_foreign_records, delete_race_data, delete_track_foreign_records


def index(request):
    """
    Main site view
    """
    return render(request, 'index.html')


def employees(request):
    """
    View used to retrieve employees data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('pesel', 'stanowisko', 'nazwisko', 'placa', 'nazwa_zesp'):
            field = response.get('field')
        else:
            field = "pesel"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('pesel', 'stanowisko', 'nazwisko', 'placa', 'nazwa_zesp') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') == 'placa':
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "pesel"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search),))
            context['employees'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p ORDER BY {field} {sort_order}")
            context['employees'] = dictfetchall(cursor)

    return render(request, 'employees.html', context)


def add_driver(request):
    """
    View used to insert the driver data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('pesel'), response.get('name'), response.get('wage'), response.get('team'), response.get('birth'), response.get('country')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            # if passed starting number field is empty, pass 'None'
            if response.get('start') == '':
                starting_num = None
            else:
                starting_num = int(response.get('start'))
            with connection.cursor() as cursor:  # retrieve the 'model_id' value from the database
                cursor.execute("SELECT model_id FROM model WHERE nazwa_mod = %s AND nazwa_mar = %s", (response.get('model').upper(), response.get('marka').upper()))
                model_id = cursor.fetchone()
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_kierowce(%s, %s, %s, %s, %s, %s, %s, %s);", (response.get('pesel'), response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), response.get('birth'), response.get('country').upper(), starting_num, model_id))
                    return HttpResponseRedirect('/employees/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_pracownicy" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                    if "pracownicy_placa_check" in str(e):
                        context["error"] = "Płaca musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_driver.html', context)


def modify_driver(request, driver_id):
    """
    View used to modify the driver data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM (SELECT p.pesel, p.nazwisko, p.placa, p.nazwa_zesp, k.data_ur, k.kraj_ur, k.numer_start, k.model_id FROM pracownicy p LEFT JOIN kierowcy k ON p.pesel = k.pesel) AS sub_query WHERE sub_query.pesel = %s", (driver_id,))
        context = {'driver': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('pesel'), response.get('name'), response.get('wage'), response.get('team'), response.get('birth'), response.get('country')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            # if passed starting number field is empty, pass 'None'
            if response.get('start') == '':
                starting_num = None
            else:
                starting_num = int(response.get('start'))
            try:
                with connection.cursor() as cursor:  # update employee data table
                    cursor.execute("UPDATE pracownicy SET nazwisko=%s, placa=%s, nazwa_zesp=%s WHERE pesel=%s", (response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), driver_id, ))
                with connection.cursor() as cursor:  # update driver data table
                    cursor.execute("UPDATE kierowcy SET data_ur=%s, kraj_ur=%s, numer_start=%s, model_id=%s WHERE pesel=%s", (response.get('birth'), response.get('country').upper(), starting_num, int(response.get('model_id')), driver_id))
                    return HttpResponseRedirect("/employees/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "pk_pracownicy" in str(e):
                    context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                if "pracownicy_placa_check" in str(e):
                    context["error"] = "Płaca musi być większa niż 0"
                if "fk_pracownicy_zespoly" in str(e):
                    context["error"] = "Nie istnieje zespół o podanym identyfikatorze"
                if "fk_kierowcy_model" in str(e):
                    context["error"] = "Nie istnieje model o podanym identyfikatorze"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_driver.html', context)


def delete_driver(request, employee_id):
    """
    View used to delete driver data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_employee.html', context)
    if request.method == 'POST':
        delete_employee_data('kierowca', employee_id)
        return HttpResponseRedirect('/employees/')


def add_engineer(request):
    """
    View used to insert the engineer data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_inzyniera(%s, %s, %s, %s, %s, %s);", (response.get('pesel'), response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), response.get('uni').upper(), response.get('spec').upper()))
                    return HttpResponseRedirect('/employees/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_pracownicy" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                    if "pracownicy_placa_check" in str(e):
                        context["error"] = "Płaca musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_engineer.html', context)


def modify_engineer(request, engineer_id):
    """
    View used to modify the engineer data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM (SELECT p.pesel, p.nazwisko, p.placa, p.nazwa_zesp, i.nazwa_uczel, i.spec FROM pracownicy p LEFT JOIN inzynier i ON p.pesel = i.pesel) AS sub_query WHERE sub_query.pesel = %s", (engineer_id,))
        context = {'engineer': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update employee data table
                    cursor.execute("UPDATE pracownicy SET nazwisko=%s, placa=%s, nazwa_zesp=%s WHERE pesel=%s", (response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), engineer_id))
                with connection.cursor() as cursor:  # update driver data table
                    cursor.execute("UPDATE inzynier SET nazwa_uczel=%s, spec=%s WHERE pesel=%s", (response.get('uni').upper(), response.get('spec').upper(), engineer_id))
                    return HttpResponseRedirect("/employees/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "pk_pracownicy" in str(e):
                    context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                if "pracownicy_placa_check" in str(e):
                    context["error"] = "Płaca musi być większa niż 0"
                if "fk_pracownicy_zespoly" in str(e):
                    context["error"] = "Nie istnieje zespół o podanym identyfikatorze"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_engineer.html', context)


def delete_engineer(request, employee_id):
    """
    View used to delete engineer data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_employee.html', context)
    if request.method == 'POST':
        delete_employee_data('inzynier', employee_id)
        return HttpResponseRedirect('/employees/')


def add_coach(request):
    """
    View used to insert the coach data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_trenera(%s, %s, %s, %s, %s);", (response.get('pesel'), response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), response.get('exp')))
                    return HttpResponseRedirect('/employees/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_pracownicy" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                    if "pracownicy_placa_check" in str(e):
                        context["error"] = "Płaca musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_coach.html', context)


def modify_coach(request, coach_id):
    """
    View used to modify the coach data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM (SELECT p.pesel, p.nazwisko, p.placa, p.nazwa_zesp, t.dosw_od FROM pracownicy p LEFT JOIN trener t ON p.pesel = t.pesel) AS sub_query WHERE sub_query.pesel = %s", (coach_id,))
        context = {'coach': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update employee data table
                    cursor.execute("UPDATE pracownicy SET nazwisko=%s, placa=%s, nazwa_zesp=%s WHERE pesel=%s", (response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), coach_id,))
                with connection.cursor() as cursor:  # update driver data table
                    cursor.execute("UPDATE trener SET dosw_od=%s WHERE pesel=%s", (response.get('exp'), coach_id,))
                    return HttpResponseRedirect("/employees/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "pk_pracownicy" in str(e):
                    context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                if "pracownicy_placa_check" in str(e):
                    context["error"] = "Płaca musi być większa niż 0"
                if "fk_pracownicy_zespoly" in str(e):
                    context["error"] = "Nie istnieje zespół o podanym identyfikatorze"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_coach.html', context)


def delete_coach(request, employee_id):
    """
    View used to delete coach data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_employee.html', context)
    if request.method == 'POST':
        delete_employee_data('trener', employee_id)
        return HttpResponseRedirect('/employees/')


def add_mechanic(request):
    """
    View used to insert the mechanic data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_mechanika(%s, %s, %s, %s, %s);", (response.get('pesel'), response.get('name').upper(), int(response.get('wage')),response.get('team').upper(), response.get('role')))
                    return HttpResponseRedirect('/employees/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_pracownicy" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                    if "pracownicy_placa_check" in str(e):
                        context["error"] = "Płaca musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_mechanic.html', context)


def modify_mechanic(request, mechanic_id):
    """
    View used to modify the mechanic data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM (SELECT p.pesel, p.nazwisko, p.placa, p.nazwa_zesp, m.rola FROM pracownicy p LEFT JOIN mechanik m ON p.pesel = m.pesel) AS sub_query WHERE sub_query.pesel = %s",
            (mechanic_id,))
        context = {'mechanic': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update employee data table
                    cursor.execute("UPDATE pracownicy SET nazwisko=%s, placa=%s, nazwa_zesp=%s WHERE pesel=%s", (response.get('name').upper(), int(response.get('wage')), response.get('team').upper(), mechanic_id,))
                with connection.cursor() as cursor:  # update driver data table
                    cursor.execute("UPDATE mechanik SET rola=%s WHERE pesel=%s", (response.get('role'), mechanic_id,))
                    return HttpResponseRedirect("/employees/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "pk_pracownicy" in str(e):
                    context["error"] = "W tabeli istnieje już wpis o takim peselu. Wprowadź inny pesel"
                if "pracownicy_placa_check" in str(e):
                    context["error"] = "Płaca musi być większa niż 0"
                if "fk_pracownicy_zespoly" in str(e):
                    context["error"] = "Nie istnieje zespół o podanym identyfikatorze"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_mechanic.html', context)


def delete_mechanic(request, employee_id):
    """
    View used to delete mechanic data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_employee.html', context)
    if request.method == 'POST':
        delete_employee_data('mechanik', employee_id)
        return HttpResponseRedirect('/employees/')


def team(request, team_id):
    """
    View used to retrieve team data from the database
    """
    context = dict()
    filter_flag_driver = False
    filter_flag_engineer = False
    filter_flag_coach = False
    filter_flag_mechanic = False
    filter_flag_car = False
    filter_flag_sponsor = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field_driver') in ('p.pesel', 'nazwisko', 'placa', 'data_ur', 'kraj_ur', 'numer_start', 'model_id'):
            field_driver = response.get('field_driver')
        else:
            field_driver = "p.pesel"
        if response.get('field_engineer') in ('p.pesel', 'nazwisko', 'placa', 'nazwa_uczel', 'spec'):
            field_engineer = response.get('field_engineer')
        else:
            field_engineer = "p.pesel"
        if response.get('field_coach') in ('p.pesel', 'nazwisko', 'placa', 'dosw_od'):
            field_coach = response.get('field_coach')
        else:
            field_coach = "p.pesel"
        if response.get('field_mechanic') in ('p.pesel', 'nazwisko', 'placa', 'rola'):
            field_mechanic = response.get('field_mechanic')
        else:
            field_mechanic = "p.pesel"
        if response.get('field_car') in ('vin', 'moc', 'masa', 'rok_prod', 'model_id'):
            field_car = response.get('field_car')
        else:
            field_car = "vin"
        if response.get('field_sponsor') in ('lei', 'nazwa_spon', 'kraj_spon', 'kapital'):
            field_sponsor = response.get('field_sponsor')
        else:
            field_sponsor = "lei"
        if response.get('sort_order_driver') in ('asc', 'desc'):
            sort_order_driver = response.get('sort_order_driver')
        else:
            sort_order_driver = 'ASC'
        if response.get('sort_order_engineer') in ('asc', 'desc'):
            sort_order_engineer = response.get('sort_order_engineer')
        else:
            sort_order_engineer = 'ASC'
        if response.get('sort_order_coach') in ('asc', 'desc'):
            sort_order_coach = response.get('sort_order_coach')
        else:
            sort_order_coach = 'ASC'
        if response.get('sort_order_mechanic') in ('asc', 'desc'):
            sort_order_mechanic = response.get('sort_order_mechanic')
        else:
            sort_order_mechanic = 'ASC'
        if response.get('sort_order_car') in ('asc', 'desc'):
            sort_order_car = response.get('sort_order_car')
        else:
            sort_order_car = 'ASC'
        if response.get('sort_order_sponsor') in ('asc', 'desc'):
            sort_order_sponsor = response.get('sort_order_sponsor')
        else:
            sort_order_sponsor = 'ASC'

        # if search keyword is present, change the flow of the view
        if response.get('keyword_driver') is not None and response.get('keyword_driver') in ('p.pesel', 'nazwisko', 'placa', 'data_ur', 'kraj_ur', 'numer_start', 'model_id') and response.get('search_driver') is not None and response.get('search_driver') != '':
            keyword_driver = response.get('keyword_driver')
            if response.get('keyword_driver') == 'placa':
                try:
                    search_driver = int(response.get('search_driver'))
                    filter_flag_driver = True
                except ValueError as e:
                    print(e)
                    filter_flag_driver = False
            elif response.get('keyword_driver') == 'data_ur':
                try:
                    # TODO [team():driver searching]: implement filtering by date
                    print(response.get('search_driver'))
                except:
                    print("ERROR")
            else:
                search_driver = response.get('search_driver')
                filter_flag_driver = True
        if response.get('keyword_engineer') is not None and response.get('keyword_engineer') in ('p.pesel', 'nazwisko', 'placa', 'nazwa_uczel', 'spec') and response.get('search_engineer') is not None and response.get('search_engineer') != '':
            keyword_engineer = response.get('keyword_engineer')
            if response.get('keyword_engineer') == 'placa':
                try:
                    search_engineer = int(response.get('search_engineer'))
                    filter_flag_engineer = True
                except ValueError as e:
                    print(e)
                    filter_flag_engineer = False
            else:
                search_engineer = response.get('search_engineer')
                filter_flag_engineer = True
        if response.get('keyword_coach') is not None and response.get('keyword_coach') in ('p.pesel', 'nazwisko', 'placa', 'dosw_od') and response.get('search_coach') is not None and response.get('search_coach') != '':
            keyword_coach = response.get('keyword_coach')
            if response.get('keyword_coach') == 'placa':
                try:
                    search_coach = int(response.get('search_coach'))
                    filter_flag_coach = True
                except ValueError as e:
                    print(e)
                    filter_flag_coach = False
            elif response.get('keyword_coach') == 'dosw_od':
                try:
                    # TODO [team():coach searching]: implement filtering by date
                    print(response.get('search_coach'))
                except:
                    print("ERROR")
            else:
                search_coach = response.get('search_engineer')
                filter_flag_coach = True
        if response.get('keyword_mechanic') is not None and response.get('keyword_mechanic') in ('p.pesel', 'nazwisko', 'placa', 'rola') and response.get('search_mechanic') is not None and response.get('search_mechanic') != '':
            keyword_mechanic = response.get('keyword_mechanic')
            if response.get('keyword_mechanic') == 'placa':
                try:
                    search_mechanic = int(response.get('search_mechanic'))
                    filter_flag_mechanic = True
                except ValueError as e:
                    print(e)
                    filter_flag_mechanic = False
            else:
                search_mechanic = response.get('search_mechanic')
                filter_flag_mechanic = True
        if response.get('keyword_car') is not None and response.get('keyword_car') in ('vin', 'moc', 'masa', 'rok_prod', 'model_id') and response.get('search_car') is not None and response.get('search_car') != '':
            keyword_car = response.get('keyword_car')
            if response.get('keyword_car') in ('moc', 'masa'):
                try:
                    search_car = int(response.get('search_car'))
                    filter_flag_car = True
                except ValueError as e:
                    print(e)
                    filter_flag_car = False
            elif response.get('keyword_car') == 'rok_prod':
                try:
                    # TODO [team():cars searching]: implement filtering by date
                    print(response.get('search_car'))
                except:
                    print("ERROR")
            else:
                search_car = response.get('search_car')
                filter_flag_car = True
        if response.get('keyword_sponsor') is not None and response.get('keyword_sponsor') in ('lei', 'nazwa_spon', 'kraj_spon', 'kapital') and response.get('search_sponsor') is not None and response.get('search_sponsor') != '':
            keyword_sponsor = response.get('keyword_sponsor')
            if response.get('keyword_sponsor') == 'kapital':
                try:
                    search_sponsor = int(response.get('search_sponsor'))
                    filter_flag_sponsor = True
                except ValueError as e:
                    print(e)
                    filter_flag_sponsor = False
            else:
                search_sponsor = response.get('search_sponsor')
                filter_flag_sponsor = True
    else:
        field_driver = "p.pesel"
        field_engineer = "p.pesel"
        field_coach = "p.pesel"
        field_mechanic = "p.pesel"
        field_car = "vin"
        field_sponsor = "lei"
        sort_order_driver = 'ASC'
        sort_order_engineer = 'ASC'
        sort_order_coach = 'ASC'
        sort_order_mechanic = 'ASC'
        sort_order_car = 'ASC'
        sort_order_sponsor = 'ASC'
    context['curr_sorting_field_driver'] = field_driver
    context['curr_sorting_field_engineer'] = field_engineer
    context['curr_sorting_field_coach'] = field_coach
    context['curr_sorting_field_mechanic'] = field_mechanic
    context['curr_sorting_field_car'] = field_car
    context['curr_sorting_field_sponsor'] = field_sponsor
    context['curr_sorting_order_driver'] = sort_order_driver
    context['curr_sorting_order_engineer'] = sort_order_engineer
    context['curr_sorting_order_coach'] = sort_order_coach
    context['curr_sorting_order_mechanic'] = sort_order_mechanic
    context['curr_sorting_order_car'] = sort_order_car
    context['curr_sorting_order_sponsor'] = sort_order_sponsor
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM zespoly z WHERE z.nazwa_zesp=%s", (team_id, ))
        context['team'] = dictfetchall(cursor)[0]

    if filter_flag_driver:
        context['curr_keyword_driver'] = keyword_driver
        context['curr_search_driver'] = search_driver
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN kierowcy k ON p.pesel = k.pesel WHERE p.stanowisko = 'kierowca' AND p.nazwa_zesp=%s AND {keyword_driver} = %s ORDER BY {field_driver} {sort_order_driver}", (team_id, str(search_driver), ))
            context['drivers'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN kierowcy k ON p.pesel = k.pesel WHERE p.stanowisko = 'kierowca' AND p.nazwa_zesp=%s ORDER BY {field_driver} {sort_order_driver}", (team_id, ))
            context['drivers'] = dictfetchall(cursor)

    if filter_flag_engineer:
        context['curr_keyword_engineer'] = keyword_engineer
        context['curr_search_engineer'] = search_engineer
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN inzynier i ON p.pesel = i.pesel WHERE p.stanowisko = 'inzynier' AND p.nazwa_zesp=%s AND {keyword_engineer} = %s ORDER BY {field_engineer} {sort_order_engineer}", (team_id, str(search_engineer), ))
            context['engineers'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN inzynier i ON p.pesel = i.pesel WHERE p.stanowisko = 'inzynier' AND p.nazwa_zesp=%s ORDER BY {field_engineer} {sort_order_engineer}", (team_id, ))
            context['engineers'] = dictfetchall(cursor)

    if filter_flag_coach:
        context['curr_keyword_coach'] = keyword_coach
        context['curr_search_coach'] = search_coach
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN trener t ON p.pesel = t.pesel WHERE p.stanowisko = 'trener' AND p.nazwa_zesp=%s AND {keyword_coach}=%s ORDER BY {field_coach} {sort_order_coach}", (team_id, str(search_coach), ))
            context['coaches'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN trener t ON p.pesel = t.pesel WHERE p.stanowisko = 'trener' AND p.nazwa_zesp=%s ORDER BY {field_coach} {sort_order_coach}", (team_id, ))
            context['coaches'] = dictfetchall(cursor)

    if filter_flag_mechanic:
        context['curr_keyword_mechanic'] = keyword_mechanic
        context['curr_search_mechanic'] = search_mechanic
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN mechanik m ON p.pesel = m.pesel WHERE p.stanowisko = 'mechanik' AND p.nazwa_zesp=%s AND {keyword_mechanic} = %s ORDER BY {field_mechanic} {sort_order_mechanic}", (team_id, str(keyword_mechanic), ))
            context['mechanics'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM pracownicy p LEFT JOIN mechanik m ON p.pesel = m.pesel WHERE p.stanowisko = 'mechanik' AND p.nazwa_zesp=%s ORDER BY {field_mechanic} {sort_order_mechanic}", (team_id, ))
            context['mechanics'] = dictfetchall(cursor)

    if filter_flag_car:
        context['curr_keyword_car'] = keyword_car
        context['curr_search_car'] = search_car
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM samochody s WHERE s.nazwa_zesp=%s AND {keyword_car} = %s ORDER BY {field_car} {sort_order_car}", (team_id, str(search_car), ))
            context['cars'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM samochody s WHERE s.nazwa_zesp=%s ORDER BY {field_car} {sort_order_car}", (team_id, ))
            context['cars'] = dictfetchall(cursor)

    if filter_flag_sponsor:
        context['curr_keyword_sponsor'] = keyword_sponsor
        context['curr_search_sponsor'] = search_sponsor
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM sponsor_zespol sz LEFT OUTER JOIN sponsorzy s ON s.lei=sz.sponsorzy_lei WHERE sz.zespoly_nazwa_zesp=%s AND {keyword_sponsor} = %s ORDER BY {field_sponsor} {sort_order_sponsor}", (team_id, str(search_sponsor), ))
            context['sponsors'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM sponsor_zespol sz LEFT OUTER JOIN sponsorzy s ON s.lei=sz.sponsorzy_lei WHERE sz.zespoly_nazwa_zesp=%s ORDER BY {field_sponsor} {sort_order_sponsor}", (team_id,))
            context['sponsors'] = dictfetchall(cursor)

    return render(request, 'team.html', context)


def teams(request):
    """
    View used to retrieve teams list from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('nazwa_zesp', 'kraj_zesp', 'repr_marka'):
            field = response.get('field')
        else:
            field = "nazwa_zesp"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('nazwa_zesp', 'kraj_zesp', 'repr_marka') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            search = response.get('search')
            filter_flag = True
    else:
        field = "nazwa_zesp"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM zespoly z WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search),))
            context['teams'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM zespoly z ORDER BY {field} {sort_order}")
            context['teams'] = dictfetchall(cursor)

    return render(request, 'teams.html', context)


def add_team(request):
    """
    View used to insert the team data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("INSERT INTO zespoly VALUES (%s, %s, %s);", (response.get('name').upper(), response.get('country').upper(), response.get('corp').upper()))
                    return HttpResponseRedirect('/teams/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_zespoly" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim identyfikatorze. Wprowadź inna nazwę zespołu"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_team.html', context)


def modify_team(request, team_id):
    """
    View used to modify the team data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM zespoly WHERE nazwa_zesp = %s", (team_id,))
        context = {'team': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute("UPDATE zespoly SET kraj_zesp=%s, repr_marka=%s WHERE nazwa_zesp=%s", (response.get('country').upper(), response.get('corp').upper(), team_id, ))
                    return HttpResponseRedirect("/teams/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_team.html', context)


def delete_team(request, team_id):
    """
    View used to delete team data from the database
    """
    context = dict()
    if request.method == 'GET':
        with connection.cursor() as cursor:
            cursor.execute("SELECT nazwa_zesp FROM zespoly z WHERE z.nazwa_zesp=%s", (team_id,))
            context = {'team': dictfetchall(cursor)[0]}
        return render(request, 'delete_team.html', context)
    if request.method == 'POST':
        delete_team_foreign_records(team_id)
        with connection.cursor() as cursor:  # delete team data from the table
            # TODO [delete_team()]: wrap the cursor in try-except block to avoid potential errors
            cursor.execute("DELETE FROM zespoly z WHERE z.nazwa_zesp=%s", (team_id,))
        return HttpResponseRedirect('/teams/')


def car(request, car_id):
    """
    View used to retrieve car data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('data_rozp', 'mechanik_pesel', 'data_zak', 'nazwa_zmian', 'koszt'):
            field = response.get('field')
        else:
            field = "data_rozp"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('data_rozp', 'mechanik_pesel', 'data_zak', 'nazwa_zmian', 'koszt') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') == 'koszt':
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            elif response.get('keyword') in ('data_rozp', 'data_zak'):
                try:
                    # TODO [car() searching]: implement filtering by date
                    print(response.get('search'))
                except:
                    print("ERROR")
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "data_rozp"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM samochody s WHERE s.vin=%s", (car_id, ))
        context['car'] = dictfetchall(cursor)[0]
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT ms.mechanik_pesel, s.data_rozp, s.data_zak, s.nazwa_zmian, s.koszt, s.opis FROM serwis s LEFT OUTER JOIN mechanik_serwis ms on s.vin = ms.serwis_vin and s.data_rozp = ms.serwis_data_rozp WHERE s.vin=%s AND {keyword} = %s ORDER BY {field} {sort_order}", (car_id, str(search),))
            context['service'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT ms.mechanik_pesel, s.data_rozp, s.data_zak, s.nazwa_zmian, s.koszt, s.opis FROM serwis s LEFT OUTER JOIN mechanik_serwis ms on s.vin = ms.serwis_vin and s.data_rozp = ms.serwis_data_rozp WHERE s.vin=%s ORDER BY {field} {sort_order}", (car_id, ))
            context['service'] = dictfetchall(cursor)
    return render(request, 'car.html', context)


def cars(request):
    """
    View used to retrieve cars and models data from the database
    """
    context = dict()
    filter_flag_car = False
    filter_flag_model = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field_car') in ('vin', 'nazwa_zesp', 'moc', 'masa', 'rok_prod', 'model_id'):
            field_car = response.get('field_car')
        else:
            field_car = "vin"
        if response.get('field_model') in ('model_id', 'nazwa_mod', "nazwa_mar"):
            field_model = response.get('field_model')
        else:
            field_model = "model_id"
        if response.get('sort_order_car') in ('asc', 'desc'):
            sort_order_car = response.get('sort_order_car')
        else:
            sort_order_car = 'ASC'
        if response.get('sort_order_model') in ('asc', 'desc'):
            sort_order_model = response.get('sort_order_model')
        else:
            sort_order_model = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword_car') is not None and response.get('keyword_car') in ('vin', 'nazwa_zesp', 'moc', 'masa', 'rok_prod', 'model_id') and response.get('search_car') is not None and response.get('search_car') != '':
            keyword_car = response.get('keyword_car')
            if response.get('keyword_car') in ('moc', 'masa'):
                try:
                    search_car = int(response.get('search_car'))
                    filter_flag_car = True
                except ValueError as e:
                    print(e)
                    filter_flag_car = False
            elif response.get('keyword_car') == 'rok_prod':
                try:
                    # TODO [cars() searching]: implement filtering by date
                    print(response.get('search_car'))
                except:
                    print("ERROR")
            else:
                search_car = response.get('search_car')
                filter_flag_car = True
        if response.get('keyword_model') is not None and response.get('keyword_model') in ('model_id', 'nazwa_mod', "nazwa_mar") and response.get('search_model') is not None and response.get('search_model') != '':
            keyword_model = response.get('keyword_model')
            if response.get('keyword_model') == 'model_id':
                try:
                    search_model = int(response.get('search_model'))
                    filter_flag_model = True
                except ValueError as e:
                    print(e)
                    filter_flag_model = False
            else:
                search_model = response.get('search_model')
                filter_flag_model = True
    else:
        field_car = "nazwa_zesp"
        field_model = "model_id"
        sort_order_car = 'ASC'
        sort_order_model = 'ASC'
    context['curr_sorting_field_car'] = field_car
    context['curr_sorting_field_model'] = field_model
    context['curr_sorting_order_car'] = sort_order_car
    context['curr_sorting_order_model'] = sort_order_model
    if filter_flag_car:
        context['curr_keyword_car'] = keyword_car
        context['curr_search_car'] = search_car
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM samochody s WHERE {keyword_car} = %s ORDER BY {field_car} {sort_order_car}", (str(search_car),))
            context['cars'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM samochody s ORDER BY {field_car} {sort_order_car}")
            context['cars'] = dictfetchall(cursor)
    if filter_flag_model:
        context['curr_keyword_model'] = keyword_model
        context['curr_search_model'] = search_model
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM model m WHERE {keyword_model} = %s ORDER BY {field_model} {sort_order_model}", (str(search_model), ))
            context['models'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM model m ORDER BY {field_model} {sort_order_model}")
            context['models'] = dictfetchall(cursor)
    return render(request, 'cars.html', context)
    return render(request, 'cars.html', context)


def add_car(request):
    """
    View used to insert the car data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('vin'), response.get('model'), response.get('manufacturer'), response.get('team'), response.get('hp'), response.get('weight')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            # if passed production date field is empty, pass 'None'
            if response.get('prod') == '':
                prod = None
            else:
                prod = response.get('prod') + '-01-01'
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_samochod(%s, %s, %s, %s, %s, %s, %s);", (response.get('vin').upper(), response.get('model').upper(), response.get('manufacturer').upper(), response.get('team').upper(), int(response.get('hp')), int(response.get('weight')), prod, ))
                    return HttpResponseRedirect('/cars/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_samochody" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim numerze VIN. Wprowadź inny VIN"
                    if "samochody_masa_check" in str(e):
                        context["error"] = "Masa samochodu musi być większa niż 0"
                    if "samochody_moc_check" in str(e):
                        context["error"] = "Moc samochodu musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_car.html', context)


def modify_car(request, car_id):
    """
    View used to modify the car data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM samochody WHERE vin = %s", (car_id,))
        context = {'car': dictfetchall(cursor)[0]}
        if context["car"]["rok_prod"] is None:
            context["car"]["rok_prod"] = None
        else:
            context["car"]["rok_prod"] = int(str(context["car"]["rok_prod"]).split("-")[0])
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('vin'), response.get('team'), response.get('hp'), response.get('weight'), response.get('model_id')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            # if passed production date field is empty, pass 'None'
            if response.get('prod') == '':
                prod = None
            else:
                prod = response.get('prod') + '-01-01'
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute("UPDATE samochody SET nazwa_zesp=%s, moc=%s, masa=%s, rok_prod=%s, model_id=%s WHERE vin=%s", (response.get('team').upper(), int(response.get('hp')), int(response.get('weight')), prod, int(response.get('model_id')), car_id,))
                    return HttpResponseRedirect("/cars/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "samochody_masa_check" in str(e):
                    context["error"] = "Masa samochodu musi być większa niż 0"
                if "samochody_moc_check" in str(e):
                    context["error"] = "Moc samochodu musi być większa niż 0"
                if "fk_samochody_model" in str(e):
                    context["error"] = "Nie istnieje model o podanym identyfikatorze"
                if "fk_samochody_zespoly" in str(e):
                    context["error"] = "Nie istnieje zespół o podanym identyfikatorze"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_car.html', context)


def delete_car(request, car_id):
    """
    View used to delete car data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_car.html', context)
    if request.method == 'POST':
        delete_car_data(car_id)
        return HttpResponseRedirect('/cars/')


def modify_model(request, model_id):
    """
    View used to modify the model data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM model WHERE model_id = %s", (model_id,))
        context = {'model': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute("UPDATE model SET nazwa_mod=%s, nazwa_mar=%s WHERE model_id=%s", (response.get("model").upper(), response.get("manufacturer").upper(), model_id, ))
                    return HttpResponseRedirect("/cars/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_model.html', context)


def delete_model(request, model_id):
    """
    View used to delete model data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_model.html', context)
    if request.method == 'POST':
        delete_model_foreign_records(model_id)
        with connection.cursor() as cursor:  # delete drivers data from the table
            # TODO [delete_model()]: wrap the cursor in try-except block to avoid potential errors
            cursor.execute("DELETE FROM model m WHERE m.model_id=%s", (model_id,))
        return HttpResponseRedirect('/cars/')


def add_service(request, car_id):
    context = {"car": {"vin": car_id}}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('vin'), response.get('pesel'), response.get('change'), response.get('strt_dt'), response.get('end_dt')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            # if passed description field is empty, pass 'None'
            if response.get('desc') is None:
                desc = None
            else:
                desc = response.get('desc')
            # if passed description field is empty, pass 'None'
            if response.get('cost') == '':
                cost = None
            else:
                cost = int(response.get('cost'))
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_serwis(%s, %s, %s, %s, %s, %s, %s);", (car_id, response.get('pesel'), response.get('change').upper(), response.get('strt_dt'), response.get('end_dt'), cost, desc, ))
                    return HttpResponseRedirect('/cars/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)

                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'add_service.html', context)


def modify_service(request, car_id, service_id):
    """
    View used to modify the service data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM (SELECT ms.mechanik_pesel, s.vin, s.data_rozp, s.data_zak, s.nazwa_zmian, s.koszt, s.opis FROM serwis s LEFT OUTER JOIN mechanik_serwis ms ON s.vin=ms.serwis_vin AND s.data_rozp = ms.serwis_data_rozp) AS sub_query WHERE sub_query.vin=%s AND sub_query.data_rozp=%s", (car_id, service_id,))
        context = {'service': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('vin'), response.get('pesel'), response.get('change'), response.get('strt_dt'), response.get('end_dt')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            # if passed description field is empty, pass 'None'
            if response.get('desc') is None:
                desc = None
            else:
                desc = response.get('desc')
            # if passed description field is empty, pass 'None'
            if response.get('cost') == '':
                cost = None
            else:
                cost = int(response.get('cost'))
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute("UPDATE serwis SET nazwa_zmian=%s, data_zak=%s, koszt=%s, opis=%s WHERE vin=%s AND data_rozp=%s", (response.get('change'), response.get('end_dt'), cost, desc, car_id, service_id));
                    return HttpResponseRedirect("/cars/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "serwis_check" in str(e):
                    context["error"] = "Data zakończenia nie może być wcześniejsza niż data rozpoczęcia serwisu"
                if "serwis_koszt_check" in str(e):
                    context["error"] = "Koszt serwisu musi być większy niż 0"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_service.html', context)


def delete_service(request, car_id, service_id):
    """
    View used to delete model data from the database
    """
    context = dict()
    if request.method == 'GET':
        with connection.cursor() as cursor:
            cursor.execute("SELECT vin FROM samochody s WHERE s.vin=%s", (car_id,))
            context = {'car': dictfetchall(cursor)[0]}
        return render(request, 'delete_service.html', context)
    if request.method == 'POST':
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM mechanik_serwis ms WHERE ms.serwis_vin=%s AND ms.serwis_data_rozp=%s", (car_id, service_id,))
            cursor.execute("DELETE FROM serwis s WHERE s.vin=%s AND s.data_rozp=%s", (car_id, service_id,))
        return HttpResponseRedirect('/cars/')


def tracks(request):
    """
    View used to retrieve tracks data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('nazwa_tor', 'dlugosc', 'kraj_tor', 'adres', 'data_otw', 'pojemnosc'):
            field = response.get('field')
        else:
            field = "nazwa_tor"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('nazwa_tor', 'dlugosc', 'kraj_tor', 'adres', 'data_otw', 'pojemnosc') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') in ('dlugosc', 'pojemnosc'):
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            elif response.get('keyword') == 'data_otw':
                try:
                    # TODO [tracks() searching]: implement filtering by date
                    print(response.get('search'))
                except:
                    print("ERROR")
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "nazwa_tor"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM tory t WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search), ))
            context['tracks'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM tory t ORDER BY {field} {sort_order}")
            context['tracks'] = dictfetchall(cursor)

    return render(request, 'tracks.html', context)


def add_track(request):
    """
    View used to insert the track data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the required values are empty
        if '' in (response.get('track'), response.get('length'), response.get('country')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            # if passed capacity field is empty, pass 'None'
            if response.get('cap') is '':
                cap = None
            else:
                cap = int(response.get('cap'))
            # if passed opening date field is empty, pass 'None'
            if response.get('date') == '':
                date = None
            else:
                date = response.get('date')
            # if passed opening date field is empty, pass 'None'
            if response.get('adr') == '':
                adr = ''
            else:
                adr = response.get('adr').upper()
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("INSERT INTO tory VALUES (%s, %s, %s, %s, %s, %s);", (response.get('track').upper(), int(response.get('length')), response.get('country').upper(), response.get('adr').upper(), date, cap))
                    return HttpResponseRedirect('/tracks/')
                except (DataError, ValueError) as e:
                    print(e)
                    context[
                        "error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_tory" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim identyfikatorze. Wprowadź inną nazwę toru"
                    if "tory_dlugosc_check" in str(e):
                        context["error"] = "Długość musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_track.html', context)


def modify_track(request, track_id):
    """
    View used to modify the track data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * From tory WHERE nazwa_tor = %s", (track_id, ))
        context = {'track': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the required values are empty
        if '' in (response.get('track'), response.get('length'), response.get('country')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            # if passed capacity field is empty, pass 'None'
            if response.get('cap') is '':
                cap = None
            else:
                cap = int(response.get('cap'))
            # if passed opening date field is empty, pass 'None'
            if response.get('date') == '':
                date = None
            else:
                date = response.get('date')
            # if passed opening date field is empty, pass 'None'
            if response.get('adr') == '':
                adr = ''
            else:
                adr = response.get('adr').upper()
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute(
                        "UPDATE tory SET dlugosc=%s, kraj_tor=%s, adres=%s, data_otw=%s, pojemnosc=%s WHERE nazwa_tor=%s", (response.get('length'), response.get('country').upper(), adr, date, cap, track_id, ))
                    return HttpResponseRedirect("/tracks/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "tory_dlugosc_check" in str(e):
                    context["error"] = "dlugosc toru musi być większa niż 0"
                if "tory_pojemnosc_check" in str(e):
                    context["error"] = "pojemnosc toru musi być większa niż 0"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_track.html', context)


def delete_track(request, track_id):
    """
    View used to delete track data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_track.html', context)
    if request.method == 'POST':
        delete_track_foreign_records(track_id)
        # TODO [delete_track()]: wrap the cursor in try-except block to avoid potential errors
        with connection.cursor() as cursor:  # delete track data from the table
            cursor.execute("DELETE FROM tory t WHERE t.nazwa_tor=%s", (track_id, ))
        return HttpResponseRedirect('/tracks/')


def races(request):
    """
    View used to retrieve races data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('nazwa_wys', 'nazwa_tor', 'ilosc_okr', 'data_wys'):
            field = response.get('field')
        else:
            field = "nazwa_wys"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('nazwa_wys', 'nazwa_tor', 'ilosc_okr', 'data_wys') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') == 'ilosc_okr':
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            elif response.get('keyword') == 'data_wys':
                try:
                    # TODO [races() searching]: implement filtering by date
                    print(response.get('search'))
                except:
                    print("ERROR")
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "nazwa_wys"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM wyscigi w WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search), ))
            context['races'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM wyscigi w ORDER BY {field} {sort_order}")
            context['races'] = dictfetchall(cursor)

    return render(request, 'races.html', context)


def add_race(request):
    """
    View used to insert the race data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('race'), response.get('track'), response.get('okr'), response.get('date')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("INSERT INTO wyscigi VALUES (%s, %s, %s, %s);", (response.get('race').upper(), response.get('track').upper(), response.get('okr').upper(), response.get('date'), ))
                    return HttpResponseRedirect('/races/')
                except (DataError, ValueError) as e:
                    print(e)
                    context[
                        "error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_wyscigi" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim identyfikatorze. Wprowadź inna nazwę wyścigu"
                    if "fk_wyscigi_tory" in str(e):
                        context["error"] = "Nie istnieje tor o podanym identyfikatorze"
                    if "wyscigi_ilosc_okr_check" in str(e):
                        context["error"] = "Długość musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_race.html', context)


def modify_race(request, race_id):
    """
    View used to modify the race data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * From wyscigi WHERE nazwa_wys = %s", (race_id, ))
        context = {'race': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('race'), response.get('track'), response.get('okr'), response.get('date')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute(
                        "UPDATE wyscigi SET nazwa_tor=%s, ilosc_okr=%s, data_wys=%s WHERE nazwa_wys=%s", (response.get('track'), response.get('okr'), response.get('date'), race_id, ))
                    return HttpResponseRedirect("/races/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "fk_wyscigi_tory" in str(e):
                    context["error"] = "Nie istnieje tor o podanym identyfikatorze"
                if "wyscigi_ilosc_okr_check" in str(e):
                    context["error"] = "ilośc okrążeń wyścigu musi być większa niż 0"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_race.html', context)


def delete_race(request, race_id):
    """
    View used to delete race data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_race.html', context)
    if request.method == 'POST':
        delete_race_data(race_id)
        return HttpResponseRedirect('/races/')


def results(request):
    """
    View used to retrieve results data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('nazwa_wys', 'pozycja', 'pesel'):
            field = response.get('field')
        else:
            field = "nazwa_wys"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('nazwa_wys', 'pozycja', 'pesel') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') == 'pozycja':
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "nazwa_wys"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM wyniki w WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search), ))
            context['results'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM wyniki w ORDER BY {field} {sort_order}")
            context['results'] = dictfetchall(cursor)

    return render(request, 'results.html', context)


def add_result(request):
    """
    View used to insert the result data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('race'), response.get('pesel'), response.get('poz')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("CALL sp_wstaw_wynik(%s, %s, %s);", (response.get('race').upper(), response.get('pesel'), int(response.get('poz')), ))
                    return HttpResponseRedirect('/results/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_wyniki" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim identyfikatorze."
                    if "wyniki_pozycja_check" in str(e):
                        context["error"] = "Pozycja musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_result.html', context)


def modify_result(request, race_id, driver_id):
    """
    View used to modify the race data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * From wyniki WHERE nazwa_wys = %s AND pesel = %s", (race_id, driver_id, ))
        context = {'result': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('race'), response.get('poz'), response.get('pesel')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute(
                        "UPDATE wyniki SET pozycja=%s WHERE nazwa_wys=%s AND pesel=%s",
                        (response.get('poz'), race_id, driver_id, ));
                    return HttpResponseRedirect("/results/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "wyniki_pozycja_check" in str(e):
                    context["error"] = "pozycja w wyścigu musi być większa niż 0"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_result.html', context)


def delete_result(request, race_id, driver_id):
    """
    View used to delete result data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_result.html', context)
    if request.method == 'POST':
        with connection.cursor() as cursor:  # delete result data from the table
            cursor.execute("DELETE FROM wyniki w WHERE w.nazwa_wys=%s AND w.pesel=%s", (race_id, driver_id, ))
        return HttpResponseRedirect('/results/')


def records(request):
    """
    View used to retrieve record data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('pesel', 'czas', 'nazwa_wys', 'numer_okr'):
            field = response.get('field')
        else:
            field = "pesel"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('pesel', 'czas', 'nazwa_wys', 'numer_okr') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') == 'numer_okr':
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            elif response.get('keyword') == 'cas':
                try:
                    # TODO [records() searching]: implement filtering by time
                    print(response.get('search'))
                except:
                    print("ERROR")
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "pesel"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM rekordy r WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search), ))
            context['records'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM rekordy r ORDER BY {field} {sort_order}")
            context['records'] = dictfetchall(cursor)

    return render(request, 'records.html', context)


def add_record(request):
    """
    View used to insert the record data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in (response.get('pesel'), response.get('time'), response.get('race')):
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            # if passed lap field is empty, pass 'None'
            if response.get('numero') == '':
                numero = None
            else:
                numero = int(response.get('numero'))
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    # TODO [add_record()]: stored procedure adds the record ONLY, if it is better than previous one. Add some context[] that will be displayed in the frontend, if the situation occurs
                    cursor.execute("CALL sp_wstaw_rekord(%s, %s, %s, %s);", (response.get('pesel'), response.get('race').upper(), response.get('time'), numero))
                    return HttpResponseRedirect('/records/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "rekordy_czas_check" in str(e):
                        context["error"] = "Czas musi być większa niż 0"
                    if "rekordy_numer_okr_check" in str(e):
                        context["error"] = "Numer okrążenia musi być większa niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'add_record.html', context)


def modify_record(request, race_id):
    with connection.cursor() as cursor:
        cursor.execute("SELECT * From rekordy WHERE nazwa_wys = %s", (race_id, ))
        context = {'record': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if response.get('time') == '':
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            # if passed description field is empty, pass 'None'
            if response.get('numero') == '':
                numero = None
            else:
                numero = int(response.get('numero'))
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute(
                        "UPDATE rekordy SET czas=%s, numer_okr=%s WHERE nazwa_wys=%s", (response.get('time'), numero, race_id, ));
                    return HttpResponseRedirect("/records/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except IntegrityError as e:
                print(e)
                if "rekordy_czas_check" in str(e):
                    context["error"] = "czas rekordu musi być większa niż 0"
                if "rekordy_numer_okr_check" in str(e):
                    context["error"] = "numer okrążenia musi być większa niż 0"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_record.html', context)


def delete_record(request, record_id):
    """
    View used to delete record data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_record.html', context)
    if request.method == 'POST':
        with connection.cursor() as cursor:  # delete record data from the table
            cursor.execute("DELETE FROM rekordy r WHERE r.nazwa_wys=%s", (record_id, ))
        return HttpResponseRedirect('/records/')


def sponsor(request, sponsor_id):
    """
    View used to retrieve sponsor data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('zespoly_nazwa_zesp', 'kraj_zesp', 'repr_marka'):
            field = response.get('field')
        else:
            field = "zespoly_nazwa_zesp"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('zespoly_nazwa_zesp', 'kraj_zesp', 'repr_marka') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            search = response.get('search')
            filter_flag = True
    else:
        field = "zespoly_nazwa_zesp"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM sponsorzy s WHERE s.lei=%s", (sponsor_id,))
        context['sponsor'] = dictfetchall(cursor)[0]
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM sponsor_zespol sz LEFT OUTER JOIN zespoly z ON z.nazwa_zesp=sz.zespoly_nazwa_zesp WHERE sz.sponsorzy_lei=%s AND {keyword} = %s ORDER BY {field} {sort_order}", (sponsor_id, str(search),))
            context['teams'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM sponsor_zespol sz LEFT OUTER JOIN zespoly z ON z.nazwa_zesp=sz.zespoly_nazwa_zesp WHERE sz.sponsorzy_lei=%s ORDER BY {field} {sort_order}", (sponsor_id,))
            context['teams'] = dictfetchall(cursor)

    return render(request, 'sponsor.html', context)


def sponsors(request):
    """
    View used to retrieve sponsor data from the database
    """
    context = dict()
    filter_flag = False
    if request.method == 'POST':
        response = request.POST  # save POST request as a response

        # enforce the sorting fields, to not pass any invalid input
        if response.get('field') in ('lei', 'nazwa_spon', 'kraj_spon', 'kapital'):
            field = response.get('field')
        else:
            field = "lei"
        if response.get('sort_order') in ('asc', 'desc'):
            sort_order = response.get('sort_order')
        else:
            sort_order = 'ASC'
        # if search keyword is present, change the flow of the view
        if response.get('keyword') is not None and response.get('keyword') in ('lei', 'nazwa_spon', 'kraj_spon', 'kapital') and response.get('search') is not None and response.get('search') != '':
            keyword = response.get('keyword')
            if response.get('keyword') == 'kapital':
                try:
                    search = int(response.get('search'))
                    filter_flag = True
                except ValueError as e:
                    print(e)
                    filter_flag = False
            else:
                search = response.get('search')
                filter_flag = True
    else:
        field = "lei"
        sort_order = 'ASC'
    context['curr_sorting_field'] = field
    context['curr_sorting_order'] = sort_order
    if filter_flag:
        context['curr_keyword'] = keyword
        context['curr_search'] = search
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM sponsorzy s WHERE {keyword} = %s ORDER BY {field} {sort_order}", (str(search),))
            context['sponsors'] = dictfetchall(cursor)
    else:
        with connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM sponsorzy s ORDER BY {field} {sort_order}")
            context['sponsors'] = dictfetchall(cursor)

    return render(request, 'sponsors.html', context)


def add_sponsor(request):
    """
    View used to insert the sponsor data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("INSERT INTO sponsorzy VALUES (%s, %s, %s, %s);", (response.get('lei'), response.get('spon').upper(), response.get('country').upper(), int(response.get('capital')),))
                    return HttpResponseRedirect('/sponsors/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "pk_sponsorzy" in str(e):
                        context["error"] = "W tabeli istnieje już wpis o takim identyfikatorze. Wprowadź inny numer LEI"
                    if "sponsorzy_kapital_check" in str(e):
                        context["error"] = "Kapitał sponsora musi być większy niż 0"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_sponsor.html', context)


def add_sponsoring(request, sponsor_id):
    """
    View used to insert the sponsoring data into the database
    """
    context = dict()
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:  # if all values are filled, proceed
            with connection.cursor() as cursor:  # call the stored procedure to insert passed data into the database
                try:
                    cursor.execute("INSERT INTO sponsor_zespol VALUES (%s, %s);", (sponsor_id, response.get('team')))
                    return HttpResponseRedirect('/sponsors/')
                except (DataError, ValueError) as e:
                    print(e)
                    context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
                except IntegrityError as e:
                    print(e)
                    if "fk_sponsor_zespol_zespoly" in str(e):
                        context["error"] = "Nie istnieje zespół o podanym identyfikatorze"
                except InternalError as e:
                    print(e)
                    context["error"] = str(e).split("\n")[0]  # passes the details from the db server

    return render(request, 'add_sponsoring.html', context)


def modify_sponsor(request, sponsor_id):
    """
    View used to modify the sponsor data present on the database
    """
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM sponsorzy WHERE lei = %s", (sponsor_id,))
        context = {'sponsor': dictfetchall(cursor)[0]}
    if request.method == 'POST':
        response = request.POST  # save POST request as a response
        # verify if none of the passed values are empty
        if '' in response.values():
            context["error"] = "Błędnie wypełniony formularz. Sprawdź czy wymagane pola są wypełnione"
        else:
            try:
                with connection.cursor() as cursor:  # update team data table
                    cursor.execute("UPDATE sponsorzy SET nazwa_spon=%s, kraj_spon=%s, kapital=%s WHERE lei=%s", (response.get('spon').upper(), response.get('country').upper(), response.get('capital'), sponsor_id))
                    return HttpResponseRedirect("/sponsors/")
            except (DataError, ValueError) as e:
                print(e)
                context["error"] = "Błędnie wypełniony formularz. Sprawdź, czy dane zostały wprowadzone prawidłowo"
            except InternalError as e:
                print(e)
                context["error"] = str(e).split("\n")[0]  # passes the details from the db server
    return render(request, 'modify_sponsor.html', context)


def delete_sponsor(request, sponsor_id):
    """
    View used to delete sponsor data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_sponsor.html', context)
    if request.method == 'POST':
        with connection.cursor() as cursor:  # delete sponsor data from the table
            cursor.execute("DELETE FROM sponsor_zespol sz WHERE sz.sponsorzy_lei=%s", (sponsor_id, ))
            cursor.execute("DELETE FROM sponsorzy s WHERE s.lei=%s", (sponsor_id, ))
        return HttpResponseRedirect('/sponsors/')


def delete_sponsoring(request, team_id):
    """
    View used to delete sponsoring data from the database
    """
    context = dict()
    if request.method == 'GET':
        return render(request, 'delete_sponsor.html', context)
    if request.method == 'POST':
        with connection.cursor() as cursor:  # delete sponsoring data from the table
            cursor.execute("DELETE FROM sponsor_zespol sz WHERE sz.zespoly_nazwa_zesp=%s", (team_id,))
        return HttpResponseRedirect('/sponsors/')