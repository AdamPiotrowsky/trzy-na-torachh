from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),

    # employees
    path('employees/', views.employees, name='employees'),
    path('employees/add_driver/', views.add_driver, name='add_driver'),
    path('employees/modify_driver/<driver_id>', views.modify_driver, name='modify_driver'),
    path('employees/delete_driver/<employee_id>', views.delete_driver, name='delete_driver'),
    path('employees/add_engineer/', views.add_engineer, name='add_engineer'),
    path('employees/modify_engineer/<engineer_id>', views.modify_engineer, name='modify_engineer'),
    path('employees/delete_engineer/<employee_id>', views.delete_engineer, name='delete_engineer'),
    path('employees/add_coach/', views.add_coach, name='add_coach'),
    path('employees/modify_coach/<coach_id>', views.modify_coach, name='modify_coach'),
    path('employees/delete_coach/<employee_id>', views.delete_coach, name='delete_coach'),
    path('employees/add_mechanic/', views.add_mechanic, name='add_mechanic'),
    path('employees/modify_mechanic/<mechanic_id>', views.modify_mechanic, name='modify_mechanic'),
    path('employees/delete_mechanic/<employee_id>', views.delete_mechanic, name='delete_mechanic'),

    # teams
    path('teams/', views.teams, name='teams'),
    path('team/<team_id>/', views.team, name='team'),
    path('teams/add_team/', views.add_team, name='add_team'),
    path('team/<team_id>/modify_team/', views.modify_team, name='modify_team'),
    path('team/<team_id>/delete_team/', views.delete_team, name='delete_team'),

    # cars
    path('cars/', views.cars, name='cars'),
    path('car/<car_id>/', views.car, name='car'),
    path('add_car/', views.add_car, name='add_car'),
    path('modify_car/<car_id>', views.modify_car, name='modify_car'),
    path('delete_car/<car_id>', views.delete_car, name='delete_car'),
    path('modify_model/<model_id>', views.modify_model, name='modify_model'),
    path('delete_model/<model_id>', views.delete_model, name='delete_model'),
    path('car/<car_id>/add_service/', views.add_service, name='add_service'),
    path('car/<car_id>/modify_service/<service_id>', views.modify_service, name='modify_service'),
    path('car/<car_id>/delete_service/<service_id>', views.delete_service, name='delete_service'),

    # tracks
    path('tracks/', views.tracks, name='tracks'),
    path('add_track/', views.add_track, name='add_track'),
    path('modify_track/<track_id>', views.modify_track, name='modify_track'),
    path('delete_track/<track_id>', views.delete_track, name='delete_track'),

    # races
    path('races/', views.races, name='races'),
    path('add_race/', views.add_race, name='add_race'),
    path('modify_race/<race_id>', views.modify_race, name='modify_race'),
    path('delete_race/<race_id>', views.delete_race, name='delete_race'),

    # results
    path('results/', views.results, name='results'),
    path('add_result/', views.add_result, name='add_result'),
    path('results/<race_id>/modify_result/<driver_id>', views.modify_result, name='modify_result'),
    path('results/<race_id>/delete_result/<driver_id>', views.delete_result, name='delete_result'),

    # records
    path('records/', views.records, name='records'),
    path('add_record/', views.add_record, name='add_record'),
    path('modify_record/<race_id>', views.modify_record, name='modify_record'),
    path('records/<record_id>/delete_record/', views.delete_record, name='delete_record'),

    # sponsors
    path('sponsors/', views.sponsors, name='sponsors'),
    path('sponsor/<sponsor_id>', views.sponsor, name='sponsor'),
    path('add_sponsor/', views.add_sponsor, name='add_sponsor'),
    path('sponsor/<sponsor_id>/add_sponsoring/', views.add_sponsoring, name='add_sponsoring'),
    path('modify_sponsor/<sponsor_id>', views.modify_sponsor, name='modify_sponsor'),
    path('delete_sponsor/<sponsor_id>', views.delete_sponsor, name='delete_sponsor'),
    path('delete_sponsoring/<team_id>', views.delete_sponsoring, name='delete_sponsoring'),
]